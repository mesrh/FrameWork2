//
//  FrameWork1.h
//  FrameWork1
//
//  Created by Manoj Singhal on 12/25/17.
//  Copyright © 2017 com.geminisolutions.in. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FrameWork1.
FOUNDATION_EXPORT double FrameWork1VersionNumber;

//! Project version string for FrameWork1.
FOUNDATION_EXPORT const unsigned char FrameWork1VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FrameWork1/PublicHeader.h>


